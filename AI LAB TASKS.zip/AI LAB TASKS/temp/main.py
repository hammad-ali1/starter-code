from queue import PriorityQueue
import math


nodes = {
    'A': (0, 0),
    'B': (1, 0),
    'C': (1, 1),
    'D': (0, 1)
}

edges = {
    'A': {'B': 8, 'C': 3, 'D': 7},
    'B': {'A': 8, 'D': 4, 'C': 1},
    'C': {'A': 3, 'B': 1, 'D': 6},
    'D': {'A': 7, 'B': 4, 'C': 6},
}


def neighbors(edges, node):
    return edges[node].keys()


def cost(edges, a, b):
    return edges[a][b]


def heuristic_function(a, b, nodes):
    ax, ay = nodes[a]
    bx, by = nodes[b]
    return math.sqrt((bx-ax)**2 + (by-ay)**2)


def astar_search(start, goal):
    frontier = PriorityQueue()
    frontier.put((0, start))
    parent = {}
    cost_sum = {}
    parent[start] = None
    cost_sum[start] = 0

    while not frontier.empty():
        _, current = frontier.get()

        if current == goal:
            break

        for next_node in neighbors(edges, current):
            new_cost = cost_sum[current] + cost(edges, current, next_node)
            if next_node not in cost_sum or new_cost < cost_sum[next_node]:
                cost_sum[next_node] = new_cost
                priority = new_cost + \
                    heuristic_function(next_node, goal, nodes)
                frontier.put((priority, next_node))
                parent[next_node] = current

    return parent, cost_sum


def herustic_search(start, goal):
    frontier = PriorityQueue()
    frontier.put((0, start))
    parent = {}
    cost_sum = {}
    parent[start] = None
    cost_sum[start] = 0

    while not frontier.empty():
        _, current = frontier.get()

        if current == goal:
            break

        for next_node in neighbors(edges, current):
            new_cost = cost_sum[current] + cost(edges, current, next_node)
            if next_node not in cost_sum or new_cost < cost_sum[next_node]:
                cost_sum[next_node] = new_cost
                priority = heuristic_function(next_node, goal, nodes)
                frontier.put((priority, next_node))
                parent[next_node] = current

    return parent, cost_sum


start = 'A'
goal = 'B'
parent, cost_sum = astar_search(start, goal)

# Print the shortest path found
path = [goal]
node = goal
while node != start:
    node = parent[node]
    path.append(node)
path.reverse()
print("A star path is ")
print(path)
print("A star cost is " + str(cost_sum[goal]))

# herustic search
parent, cost_sum = herustic_search(start, goal)

# Print the shortest path found
path = [goal]
node = goal
while node != start:
    node = parent[node]
    path.append(node)
path.reverse()
print("herustic star path is ")
print(path)
print("herustic cost is " + str(cost_sum[goal]))

while True:
    try:
        expression = input("Calculate? ")
        print(eval(expression))
    except NameError:
        if(expression == "q"):
            break
        else:
            print("invalid expression. enter q to quit")
    except SyntaxError:
        print("invalid syntax")
    

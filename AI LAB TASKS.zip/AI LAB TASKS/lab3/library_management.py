import os
from utils import *
books = [
    {"name": "Harry Potter", "author": "JK Rowiling", "IBAN": "123456"},
    {"name": "My Book", "author": "John Doe", "IBAN": "222333"},
    {"name": "Hello World", "author": "foo bar", "IBAN": "443344"},
    {"name": "C++ How to program", "author": "Deitel", "IBAN": "555666"}
]
booksIssued = [
    {"studentId": "fa20-bcs-089", "IBAN": "123456",
        "dueDate":  string2Date("2023-02-02")}
]
students = [{"id": "fa20-bcs-087", "name": "Hammad Ali"}]


def showMenu():
    print("1: Show all books")
    print("2: Add a new book")
    print("3: Search a book by field")
    print("4: Delete a book by field")
    print("5: Update a book by field")
    print("6: Show all issued books")
    print("7: Issue a book")
    print("8: Return a book")
    print("9: Exit")
    try:
        return int(input())
    except ValueError:
        print("Only integers allowed")
        return -1


def getSelectedField(prompt="Search By?"):
    print(prompt)
    print("1: name")
    print("2: author")
    print("3: IBAN")
    try:
        field = int(input())
        if field == 1:
            return "name"
        elif field == 2:
            return "author"
        elif field == 3:
            return "IBAN"
        else:
            print("Out of range")
            return -1
    except ValueError:
        print("Only integers allowed")
        return -1


def clearScreen():
    os.system("cls")


def displayData(data):
    for item in data:
        print(item)


def createBook(books):
    name = input("Enter book name: ")
    author = input("Enter author name: ")
    iban = input("Enter IBAN: ")
    books.append({"name": name, "author": author, "IBAN": iban})


def searchBook(books):
    fieldToSearch = getSelectedField()
    if fieldToSearch == -1:
        return -1
    valueToSearch = input(f"Enter {fieldToSearch}: ")
    bookIdx = searchList(books, fieldToSearch, valueToSearch)
    if bookIdx == -1:
        print("Book not found")
        return -1
    else:
        return bookIdx


def issueBook():
    studentId = input("enter student id: ")
    iban = input("enter iban: ")
    try:
        due_date = string2Date(input("enter due date: "))
    except:
        print("invalid date")
        return False
    if searchList(books, "IBAN", iban) == -1:
        print("book not found")
        return False
    if searchList(students, "id", studentId) == -1:
        print("student not found")
        return False
    if searchList(booksIssued, "studentId", studentId) != -1:
        print("maximum one book allowed")
        return False
    if searchList(booksIssued, "IBAN", iban) != -1:
        print("book not available")
        return False
    booksIssued.append(
        {"studentId": studentId, "IBAN": iban, "dueDate": due_date})
    return True


def returnBook():
    studentId = input("enter student id: ")
    foundStudent = searchList(booksIssued, "studentId", studentId)
    if foundStudent == -1:
        print("student not found")
        return False
    del booksIssued[foundStudent]
    return True


def main():
    exitPogram = False
    while not exitPogram:
        clearScreen()
        choice = showMenu()
        if choice == 1:
            displayData(books)
            input("press Enter key to continue....")

        elif choice == 2:
            createBook(books)
            input("press Enter key to continue....")
        elif choice == 3:
            bookIdx = searchBook(books)
            if bookIdx != -1:
                print(f"Found book {books[bookIdx]} at index {bookIdx}")
            input("press Enter key to continue....")

        elif choice == 4:
            bookIdx = searchBook(books)
            if bookIdx == -1:
                continue
            print(f"Found book {books[bookIdx]} at index {bookIdx}")
            delete = input("Are you sure you want to delete y/n?")
            if delete == "y":
                del books[bookIdx]
            input("press Enter key to continue....")
        elif choice == 5:
            bookIdx = searchBook(books)
            if bookIdx == -1:
                continue
            print(f"Found book {books[bookIdx]} at index {bookIdx}")
            fieldToUpdate = getSelectedField(prompt="Select field to update?")
            if fieldToUpdate == -1:
                continue
            value = input(f"Enter new value for {fieldToUpdate}: ")
            books[bookIdx][fieldToUpdate] = value
            print("Update sucessful")
            input("press Enter key to continue....")
        elif choice == 6:
            displayData(booksIssued)
            input("press Enter key to continue....")
        elif choice == 7:
            if not issueBook():
                print("OPERATION FAILED")
            input("press Enter key to continue....")
        elif choice == 8:
            if not returnBook():
                print("OPERATION FAILED")
            input("press Enter key to continue....")
        elif choice == 9:
            exitPogram = True
        else:
            print("Invalid choice")


main()

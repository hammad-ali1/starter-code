import os
from utils import *
from book import Book
from student import Student
from issued import Issued
books = [
    Book("Harry Potter", "JK Rowiling", "123456"),
    Book("Hello World",  "foo bar",  "443344"),
    Book("C++ How to program", "Deitel", "555666")
]
booksIssued = [
    Issued("fa20-bcs-089",  "123456", string2Date("2023-02-02"))
]
students = [Student("fa20-bcs-087",  "Hammad Ali")]


def showMenu():
    print("1: Show all books")
    print("2: Add a new book")
    print("3: Search a book by field")
    print("4: Delete a book by field")
    print("5: Update a book by field")
    print("6: Show all issued books")
    print("7: Issue a book")
    print("8: Return a book")
    print("9: Exit")
    try:
        return int(input())
    except ValueError:
        print("Only integers allowed")
        return -1


def getSelectedField(prompt="Search By?"):
    print(prompt)
    print("1: name")
    print("2: author")
    print("3: IBAN")
    try:
        field = int(input())
        if field == 1:
            return "name"
        elif field == 2:
            return "author"
        elif field == 3:
            return "IBAN"
        else:
            print("Out of range")
            return -1
    except ValueError:
        print("Only integers allowed")
        return -1


def clearScreen():
    os.system("cls")


def displayData(data):
    if data == []:
        print("no data")
        return
    for item in data:
        print(item)


def createBook(books):
    name = input("Enter book name: ")
    author = input("Enter author name: ")
    iban = input("Enter IBAN: ")
    books.append(Book(name, author, iban))


def searchBook(books):
    fieldToSearch = getSelectedField()
    if fieldToSearch == -1:
        return -1
    valueToSearch = input(f"Enter {fieldToSearch}: ")
    booksFound = Book.searchObjectList(books, fieldToSearch, valueToSearch)
    return booksFound


def issueBook():
    studentId = input("enter student id: ")
    iban = input("enter iban: ")
    try:
        due_date = string2Date(input("enter due date: "))
    except:
        print("invalid date")
        return False
    if Book.searchObjectList(books, "IBAN", iban, strict=True) == []:
        print("book not found")
        return False
    if Student.searchObjectList(students, "id", studentId, strict=True) == []:
        print("student not found")
        return False
    if Issued.searchObjectList(booksIssued, "studentId", studentId, strict=True) != []:
        print("maximum one book allowed")
        return False
    if Issued.searchObjectList(booksIssued, "IBAN", iban, strict=True) != []:
        print("book not available")
        return False
    booksIssued.append(
        Issued(studentId, iban,  due_date))
    return True


def returnBook():
    studentId = input("enter student id: ")
    foundStudent = Issued.searchObjectList(booksIssued, "studentId", studentId,strict=True)
    if foundStudent == []:
        print("student not found")
        return False
    print("Issued Book to be returned:")
    print(foundStudent[0])
    booksIssued.remove(foundStudent[0])
    return True


def main():
    exitPogram = False
    while not exitPogram:
        clearScreen()
        choice = showMenu()
        if choice == 1:
            displayData(books)
            input("press Enter key to continue....")

        elif choice == 2:
            createBook(books)
            input("press Enter key to continue....")
        elif choice == 3:
            booksFound = searchBook(books)
            print("RESULTS:")
            displayData(booksFound)
            input("press Enter key to continue....")

        elif choice == 4:
            booksFound = searchBook(books)
            if booksFound == []:
                print("no data")
                input("press Enter key to continue....")
                continue
            print(f"Found book: {booksFound[0]}")
            delete = input("Are you sure you want to delete y/n?")
            if delete == "y":
                books.remove(booksFound[0])
            input("press Enter key to continue....")
        elif choice == 5:
            booksFound = searchBook(books)
            if booksFound == []:
                print("no data")
                input("press Enter key to continue....")
                continue
            print(f"Found book {booksFound[0]}")
            fieldToUpdate = getSelectedField(prompt="Select field to update?")
            if fieldToUpdate == -1:
                continue
            value = input(f"Enter new value for {fieldToUpdate}: ")
            booksFound[0].set(fieldToUpdate, value)
            print("Update sucessful")
            input("press Enter key to continue....")
        elif choice == 6:
            displayData(booksIssued)
            input("press Enter key to continue....")
        elif choice == 7:
            if not issueBook():
                print("OPERATION FAILED")
            input("press Enter key to continue....")
        elif choice == 8:
            if not returnBook():
                print("OPERATION FAILED")
            input("press Enter key to continue....")
        elif choice == 9:
            exitPogram = True
        else:
            print("Invalid choice")


main()

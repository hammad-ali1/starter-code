from utils import Object 

class Issued(Object):
    def __init__(self, studentId, IBAN, dueDate) -> None:
        self.studentId = studentId
        self.IBAN = IBAN
        self.dueDate = dueDate
    def __str__(self):
        return f"Student ID: {self.studentId}, IBAN: {self.IBAN}, Due Date: {self.dueDate}"


 
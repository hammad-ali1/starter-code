from utils import Object 

class Book(Object):
    def __init__(self, name, author, IBAN):
        self.name = name
        self.author = author
        self.IBAN = IBAN

    def __str__(self):
        return f"Name: {self.name}, Author: {self.author}, IBAN: {self.IBAN}"



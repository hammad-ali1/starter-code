from datetime import date

class Object:
    def has(self, field, value,strict=False):
        if strict:
            return value == getattr(self, field)
        else:
            return value in getattr(self,field)

    def set(self, field, value):
        setattr(self, field, value)

    @staticmethod
    def searchObjectList(list: list, fieldToSearch, valueToSearch, strict=False):
        return [item for item in list if item.has(fieldToSearch, valueToSearch, strict)]




def searchList(list, key, value):
    """Traverses over a list of dictionaries. 
    If a dictionary contains the key value pair it returns the index 
    where it found the object. Otherwise -1 is returned
    """
    for i, item in enumerate(list):
        if searchDict(item, key, value) != "":
            return i
    return -1


def searchDict(dict, key, value):
    """
    Searches for all key value pairs in dictionary to match with
    given key, value pair.
    If not found an empty string is returned
    """
    for k, v in dict.items():
        if k == key and value == v:
            return v
    return ""


def string2Date(dateString):
    """Converts a date in yyyy-mm-dd format to python date"""
    return date(*[int(item) for item in dateString.split('-')])

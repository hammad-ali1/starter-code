from queue import PriorityQueue


class Edge:
    # class to represent a directed edge with weight between two nodes
    # objects of this class will be stored in the adjacency list
    def __init__(self, parent, child, weight):
        self.parent = parent
        self.child = child
        self.weight = weight


class Graph:
    def __init__(self):
        # this will store adjacency list of all the nodes
        # each list contains objects of class Edge
        self.graph = {}

    def addNode(self, node):
        # adds a node in the graph with empty adjacency list
        if node not in self.graph:
            self.graph[node] = []

    def getNeighbours(self, node) -> list:
        # returns all ajacent nodes of a given node
        edges = self.getEdges(node)
        return [e.child for e in edges]

    def getEdges(self, node) -> list[Edge]:
        # get adjacency list of a node
        # if node is not in graph, an empty list is created for it
        if node not in self.graph:
            self.graph[node] = []
        return self.graph[node]

    def addDirectedEdge(self, parent, child, weight=1):
        # adds a directed edge between a parent node to its child node
        # default weight of the edge is 1
        self.addNode(parent)
        self.addNode(child)
        edges = self.getEdges(parent)
        edges.append(Edge(parent, child, weight))

    def addEdge(self, node1, node2, weight=1):
        # adds an undirected edge between two nodes
        # an undriected edge can go both ways
        self.addDirectedEdge(node1, node2, weight)
        self.addDirectedEdge(node2, node1, weight)

    def dfsTraversal(self, start, goal):
        # if node is not in our graph, throw exception
        if start not in self.graph:
            raise ValueError("Node not present in graph")
        # open list will store all the nodes that are yet to be visited
        # this list will act as a stack
        open = [start]
        # close list will store all the nodes that are have been visited
        closed = []
        # path dictionary will store
        # parent of a node that was found during the traversal
        # parent of start node is None by default
        path = {start: None}
        while open:
            # pop element from start of the list
            # (First In Last Out)
            node = open.pop(0)
            # if goal node is reached, no need to explore further
            if node == goal:
                return path
            # mark node as visited
            closed.append(node)
            neighbours = self.getNeighbours(node)
            neighboursToExplore = [n for n in neighbours if n not in closed]
            # mark current node as parent of its adjacent nodes
            for n in neighboursToExplore:
                path[n] = node
            # add ajdacent nodes, not in closed list, in the open list to explore on next iteration
            open += neighboursToExplore

    def bfsTraversal(self, start, goal):
        # if node is not in our graph, throw exception
        if start not in self.graph:
            raise ValueError("Node not present in graph")
        # open list will store all the nodes that are yet to be visited
        # this list will act as a queue
        open = [start]
        # close list will store all the nodes that are have been visited
        closed = []
        # path dictionary will store
        # parent of a node that was found during the traversal
        # parent of start node is None by default
        path = {start: None}
        while open:
            # pop element from end of the list
            # (First In First Out)
            node = open.pop()
            if node == goal:
                return path
            # mark node as visited
            closed.append(node)
            neighbours = self.getNeighbours(node)
            neighboursToExplore = [n for n in neighbours if n not in closed]
            # mark current node as parent of its adjacent nodes
            for n in neighboursToExplore:
                path[n] = node
            # add ajdacent nodes, not in closed list, in the open list to explore on next iteration
            open += neighboursToExplore

    def dijkstra(self, start, goal):
        # if node is not in our graph, throw exception
        if start not in self.graph:
            raise ValueError("Node not present in graph")
        # open list will store all the nodes that are yet to be visited
        # this list will act as a Priority Queue
        # Priority is given to node with the least cummulative weight
        # cummulative weight = (weight of nodes + weight of its ancestors)
        open = PriorityQueue()
        # weight of start node is 0
        open.put((0, start))
        # close list will store all the nodes that are have been visited
        closed = []
        path = {start: None}
        # nodeCosts stores cummulative weights of all nodes
        nodeCosts = {}
        nodeCosts[start] = 0
        while open:
            # pop node with the least cummulative weight
            node = open.get()[1]
            if node == goal:
                return path, nodeCosts[goal]
            # mark node as visited
            closed.append(node)
            edges = self.getEdges(node)
            edgesToExplore = [e for e in edges if e.child not in closed]
            for e in edgesToExplore:
                # find adjacent nodes whose previous cummulative weight is greater than
                # the new cummulative weight
                if e.child in path and nodeCosts[e.child] <= e.weight + nodeCosts[node]:
                    continue
                path[e.child] = node
                # update cummulative weight of node
                nodeCosts[e.child] = e.weight + nodeCosts[node]
                # add adjacent nodes to PQ with their cummulative weight
                open.put((e.weight + nodeCosts[node], e.child))

    def printPath(self, goal, path):
        # print path from dictionary of parent nodes
        ancestors = [goal]
        key = goal
        while path[key] != None:
            ancestors.insert(0, path[key])
            key = path[key]
        for node in ancestors:
            print(f"{node} -> ", end="")
        print("END")

data = {"first_name": "Hammad",
        "last_name": "Ali",
        "reg_no": "fa20-bcs-087",
        "age": 20,
        "gender": "M",
        "semester": 6,
        "subjects": ["DIP", "AI", "CI", "Automata Theory", "Web Technologies"]}


for key, val in data.items():
    print(f'{key}\t\t{val}')

import os
books = [
    ["Harry Potter",  "JK Rowiling",  "123456"],
    ["My Book",  "John Doe",  "222333"],
    ["Hello World",  "foo bar",  "443344"],
    ["C++ How to program",  "Deitel",  "555666"]
]


def searchList(books: list, keyword):
    return [book for book in books if keyword in book]


def showMenu():
    print("1: Show all books")
    print("2: Add a new book")
    print("3: Search a book by field")
    print("4: Delete a book by field")
    print("5: Update a book by field")
    print("6: Exit")
    try:
        return int(input())
    except ValueError:
        print("Only integers allowed")
        return -1


def getSelectedField(prompt="Search By?"):
    print(prompt)
    print("1: name")
    print("2: author")
    print("3: IBAN")
    try:
        field = int(input())
        if field == 1:
            return 0
        elif field == 2:
            return 1
        elif field == 3:
            return 2
        else:
            print("Out of range")
            return -1
    except ValueError:
        print("Only integers allowed")
        return -1


def clearScreen():
    os.system("cls")


def displayBooks(books):
    for book in books:
        print(book)


def createBook(books):
    name = input("Enter book name: ")
    author = input("Enter author name: ")
    iban = input("Enter IBAN: ")
    books.append([name,  author,  iban])


def searchBook(books):
    valueToSearch = input(f"Enter search keyword: ")
    return searchList(books, valueToSearch)


def main():
    exitPogram = False
    while not exitPogram:
        clearScreen()
        choice = showMenu()
        if choice == 1:
            displayBooks(books)
            input("press Enter key to continue....")

        elif choice == 2:
            createBook(books)
            input("press Enter key to continue....")
        elif choice == 3:
            booksFound = searchBook(books)
            if(booksFound == []):
                print("no books found")
                input("press Enter key to continue....")
            print(f"Books found")
            displayBooks(books=booksFound)
            input("press Enter key to continue....")

        elif choice == 4:
            booksFound = searchBook(books)
            if booksFound == []:
                print("no books found")
                input("press Enter key to continue....")
                continue
            print(f"Found book {booksFound[0]}")
            delete = input("Are you sure you want to delete y/n?")
            if delete == "y":
                books.remove(booksFound[0])
            input("press Enter key to continue....")
        elif choice == 5:
            booksFound = searchBook(books)
            if booksFound == []:
                print("no books found")
                input("press Enter key to continue....")
                continue
            print(f"Found book {booksFound[0]}")
            fieldToUpdate = int(getSelectedField(
                prompt="Select field to update?"))
            if fieldToUpdate == -1:
                continue
            value = input(f"Enter new value for selected field: ")
            booksFound[0][fieldToUpdate] = value
            print("Update sucessful")
            input("press Enter key to continue....")
        elif choice == 6:
            exitPogram = True
        else:
            print("Invalid choice")


main()

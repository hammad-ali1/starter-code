mat1 = [[1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]]
mat2 = [[1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]]

def add_matrices(mat1,mat2):
    result = []
    for row1, row2 in zip(mat1,mat2):
        row = []
        for val1, val2 in zip(row1,row2):
            row.append(val1 + val2)
        result.append(row)
    return result

print(add_matrices(mat1, mat2))

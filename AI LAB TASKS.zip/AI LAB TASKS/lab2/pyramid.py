def up_pyramid(rows):
    for i in range(rows):
        for space in range(rows-i):
            print(end="  ")
        for j in range(2*i+1):
            print("* ", end="")
        print()


def down_pyramid(rows):
    i = rows
    while i >= 0:
        for space in range(rows-i):
            print(end="  ")
        for j in range(2*i+1):
            print("* ", end="")
        print()
        i -= 1


up_pyramid(rows=5)
down_pyramid(rows=5)

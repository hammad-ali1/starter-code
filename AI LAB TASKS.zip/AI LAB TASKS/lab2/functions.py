def get_input(n):
    my_list = []
    my_tuple = ()
    my_dict = {}
    my_set = set()
    for i in range(n):
        item = input("enter value? ")
        my_list.append(item)
        my_dict[i] = item
        my_set.add(item)
        my_tuple = tuple(my_list)
    print("List: ", end="")
    print(my_list[-1])
    print("Set: ", end="")
    print(list(my_set)[-1])
    print("Dictionary: ", end="")
    print(list(my_dict.values())[-1])
    print("Tuple: ", end="")
    print(my_tuple[-1])


# get 3 inputs from user
# get_input(3)


def item_exists(item, iteratable: set):
    for i in iteratable:
        if i == item:
            print(f"{item} exists in {iteratable}")
            iteratable.remove(item)
            iteratable.add(4)
            return
    print(f"{item} does not exists in {iteratable}")


my_set = set((1, 2, 3))
item_exists(5, my_set)
item_exists(3, my_set)
print("New set: ", my_set)

dict1 = {"name": "Hammad", "age": 20}
dict2 = {"degree": "BSCS", "university": "CUI"}
list1 = [1, 2]
list2 = [3, 4]
tuple1 = (1, 2)
tuple2 = (3, 4)
set1 = {1, 2}
set2 = {3, 4}


def merge_dict(dict1: dict, dict2: dict):
    merged = {}
    for key, value in dict1.items():
        merged[key] = value
    for key, value in dict2.items():
        merged[key] = value
    return merged


def merge_list(list1, list2):
    return list1 + list2


def merge_set(set1, set2):
    return set1.union(set2)


print("merged dictionary", merge_dict(dict1, dict2))
print("merged list", merge_list(list1, list2))
print("merged tuple", merge_list(tuple1, tuple2))
print("merged set", merge_set(set1, set2))

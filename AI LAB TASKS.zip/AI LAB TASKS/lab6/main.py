from graph import Graph
if __name__ == "__main__":
    g = Graph()
    g.addEdge("Oradea", "Zerind", -71)
    g.addEdge("Zerind", "Arad", -75)
    g.addEdge("Arad", "Timisoara", 118)
    g.addEdge("Timisoara", "Lugoj", 111)
    g.addEdge("Lugoj", "Mchadia", 70)
    g.addEdge("Mchadia", "Drobeta", 75)
    g.addEdge("Drobeta", "Craiova", 120)
    g.addEdge("Craiova", "Rimnica Vilcea", 146)
    g.addEdge("Craiova", "Pitesti", 138)
    g.addEdge("Rimnica Vilcea", "Pitesti", 97)
    g.addEdge("Rimnica Vilcea", "Sibiu", 80)
    g.addEdge("Sibiu", "Oradea", -151)
    g.addEdge("Sibiu", "Arad", -140)
    g.addEdge("Sibiu", "Fagaras", 99)
    g.addEdge("Fagaras", "Bucharest", 211)
    g.addEdge("Bucharest", "Pitesti", 101)
    g.addEdge("Bucharest", "Giurgia", 90)
    g.addEdge("Bucharest", "Urzieeni", 85)
    g.addEdge("Urzieeni", "Hirsova", 98)
    g.addEdge("Hirsova", "Eforie", 86)
    g.addEdge("Urzieeni", "Vaslui", 142)
    g.addEdge("Vaslui", "Iasi", 92)
    g.addEdge("Iasi", "Neamt", 87)

    # Uniform Cost Search Algorithm
    path, cost = g.ucs("Arad", "Bucharest")
    print(
        f"Shortest path from Arad to Bucharest using UCS is with cost {cost}")
    g.printPath("Bucharest", path)
    print("\n")

    # Dijkstra Algorithm
    dijkstraPath, dijkstraCost = g.dijkstra("Arad", "Bucharest")
    print(
        f"Shortest path from Arad to Bucharest using Dijkstra is with cost {dijkstraCost}")
    g.printPath("Bucharest", dijkstraPath)

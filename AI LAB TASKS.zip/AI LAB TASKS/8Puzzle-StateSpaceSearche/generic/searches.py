from queue import PriorityQueue
import node


class Search:

    def __init__(self, puzzle):
        self.start = node.Node(puzzle)

    def aSearch(self, heuristic):
        actual = self.start
        leaves = PriorityQueue()
        leaves.put((actual.heuristicCost(heuristic), actual))
        closed = list()
        while True:
            if leaves.empty():
                return None
            actual = leaves.get()[1]
            if actual.isGoalState():
                # return history of states and final node
                closed.append(actual.state)
                return actual, closed[1:]
            elif actual.state not in closed:
                closed.append(actual.state)
                succ = actual.getChildren()
                while not succ.empty():
                    child = succ.get()
                    leaves.put((child.heuristicCost(
                        heuristic)+child.depth, child))

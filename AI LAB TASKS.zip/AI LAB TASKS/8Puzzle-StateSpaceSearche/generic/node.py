from queue import Queue
from copy import deepcopy


class Node:
    def __init__(self, puzzle, parent=None, move=""):
        # state of the node to store puzzle
        self.state = puzzle
        # parent puzzle state
        self.parent = parent
        # cost of node
        self.depth = 0
        if parent is None:
            self.depth = 0
            self.moves = move
        else:
            # append parent's move to this node's move
            self.depth = parent.depth+1
            self.moves = parent.moves + move

    '''
    defining < operator for priority queue, in case priority is equal
    '''

    def __lt__(self, other):
        return True

    '''
    Checks if the Node's state is a goal state.
    '''

    def isGoalState(self):
        return self.state.checkPuzzle()

    '''
    Generates the node's children states.
    '''

    def getChildren(self):
        children = Queue()
        # do all possible moves
        for m in self.state.moves:
            p = deepcopy(self.state)
            # if move is valid add it to children
            isMoveSucessful = p.doMove(m)
            if isMoveSucessful:
                children.put(Node(p, self, m))
        return children

    '''
    Return Cost of Node
    '''

    def getCost(self):
        return self.depth

    '''
    Chooses between the two available heuristics
    '''

    def heuristicCost(self, heuristic):
        return self.incorrectTilesCount() if heuristic == 0 else self.manhattanDistance()

    '''
    First heuristic - number of wrong tiles
    Every time there's a tile in the wrong place, we
    add 1 to the result. Heavily inspired in the
    puzzle.checkPuzzle() loop.
    '''

    def incorrectTilesCount(self):
        result = 0
        count = 1
        for i in range(0, self.state.size):
            for j in range(0, self.state.size):
                if self.state.puzzle[i][j] != (count % (self.state.size*self.state.size)):
                    result += 1
                count += 1
        return result

    '''
    Second heuristic - distance of wrong tiles to their
    right position. After a little bit of scheming, came
    the mathematical conclusion that:
    x = n-1 // size
    y = n-1 % size
    which concluded into the following result.
    '''

    def manhattanDistance(self):
        result = 0
        for i in range(0, self.state.size):
            for j in range(0, self.state.size):
                tileN = self.state.puzzle[i][j] - 1
                if tileN == -1:
                    # distance for the empty tile (0)
                    distance = (self.state.size-1-i)+(self.state.size-1-j)
                else:
                    # x,y cordinates of tile number n in goal state
                    xActual = tileN//self.state.size
                    yActual = tileN % self.state.size
                    distance = abs(i - xActual) + abs(j-yActual)
                result += distance
        return result

    '''
    When printing the node, we obtain the moves from the
    starting state to this specific one.
    '''

    def __str__(self):
        return " ".join(self.moves)

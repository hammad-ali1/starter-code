from puzzle import Puzzle
from searches import Search

myPuzzle = Puzzle(3)
# t.readPuzzle("1 2 3 4 5 0 6 7 8")
myPuzzle.parseMoveSequence("U U L")
print(myPuzzle)
search = Search(myPuzzle)

finalNode, history = search.aSearch(1)
for move, state in zip(finalNode.moves, history):
    print('State after doing move', move)
    print(state)

print("Considering A* 2 Search:", finalNode, "\nCost is ", finalNode.getCost())

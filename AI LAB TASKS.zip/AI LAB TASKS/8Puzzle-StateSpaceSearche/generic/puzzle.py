class Puzzle:
    def __init__(self, size):
        # size of puzzle. 3 for 8-puzzle, 4 for 15-puzzle etc
        self.size = size
        # 2-d list to store puzzle state
        self.puzzle = []
        # location of empty tile (zero) in puzzle
        self.zero = (size-1, size-1)
        self.moves = ["U", "D", "L", "R"]
        # initialize puzzle to solved state
        tile = 1
        for i in range(0, size):
            self.puzzle.append([])
            for j in range(0, size):
                self.puzzle[i].append(tile)
                tile += 1
        self.puzzle[size-1][size-1] = 0
        self.zero = (size-1, size-1)

    def __eq__(self, other):
        # check if two puzzles are equal
        return self.puzzle == other.puzzle

    def readPuzzle(self, string):
        # read puzzle from string
        # e.g 1 2 3 4 5 6 7 8 0 would be a solved state for 3x3 puzzle
        tiles = string.split(" ")
        tileNum = 0
        for i in range(0, self.size):
            for j in range(0, self.size):
                # store position of empty tile
                if int(tiles[tileNum]) == 0:
                    self.zero = (i, j)
                self.puzzle[i][j] = int(tiles[tileNum])
                tileNum += 1

    def checkPuzzle(self):
        # check if puzzle is solved
        tile = 1
        for i in range(0, self.size):
            for j in range(0, self.size):
                if self.puzzle[i][j] != (tile % (self.size*self.size)):
                    return False
                tile += 1
        return True

    def swap(self, xy1, xy2):
        # swap two tiles
        x1, y1 = xy1
        x2, y2 = xy2
        temp = self.puzzle[x1][y1]
        self.puzzle[x1][y1] = self.puzzle[x2][y2]
        self.puzzle[x2][y2] = temp

    def up(self):
        # empty tile can't be moved up if it's in first row
        if (self.zero[0] != 0):
            self.swap((self.zero[0]-1, self.zero[1]), self.zero)
            self.zero = (self.zero[0]-1, self.zero[1])
            return True
        else:
            return False

    def down(self):
        # empty tile can't be moved down if it's in last row
        if (self.zero[0] != self.size-1):
            self.swap((self.zero[0]+1, self.zero[1]), self.zero)
            self.zero = (self.zero[0]+1, self.zero[1])
            return True
        else:
            return False

    def left(self):
        # empty tile can't be moved left if it's in first column
        if (self.zero[1] != 0):
            self.swap((self.zero[0], self.zero[1]-1), self.zero)
            self.zero = (self.zero[0], self.zero[1]-1)
            return True
        else:
            return False

    def right(self):
        # empty tile can't be moved right if it's in last column
        if (self.zero[1] != self.size-1):
            self.swap((self.zero[0], self.zero[1]+1), self.zero)
            self.zero = (self.zero[0], self.zero[1]+1)
            return True
        else:
            return False

    # for printing puzzle
    def __str__(self):
        result = ""
        for i in range(0, self.size):
            for j in range(0, self.size):
                result += str(self.puzzle[i][j]) + " "
            result += '\n'
        return result

    def doMove(self, move):
        if move == "U":
            return self.up()
        if move == "D":
            return self.down()
        if move == "L":
            return self.left()
        if move == "R":
            return self.right()

    def parseMoveSequence(self, string):
        for m in string:
            self.doMove(m)

import puzzle
import sys
import searches

t = puzzle.TilePuzzle()
# t.readPuzzle("1 2 3 4 5 0 6 7 8")
t.parseMoveSequence("U U L D")
t.printPuzzle()
s = searches.Search(t)

# print("Considering A* 1 Search:", s.aSearch(0))
finalNode = s.aSearch(1)
print("Considering A* 2 Search:", finalNode, "\nCost is ", finalNode.getCost())

from random import randint


class TilePuzzle:
    def __init__(self):
        self.puzzle = []
        self.size = 3
        # location of X (zero) in puzzle
        self.zero = (2, 2)
        self.moves = ["U", "D", "L", "R"]
        count = 1
        for i in range(0, 3):
            self.puzzle.append([])
            for j in range(0, 3):
                self.puzzle[i].append(count)
                count += 1
        self.puzzle[2][2] = 0
        self.zero = (2, 2)

    def readPuzzle(self, string):
        a = string.split(" ")
        count = 0
        for i in range(0, 3):
            for j in range(0, 3):
                if int(a[count]) == 0:
                    self.zero = (i, j)
                self.puzzle[i][j] = int(a[count])
                count += 1

    def checkPuzzle(self):
        count = 1
        for i in range(0, 3):
            for j in range(0, 3):
                if self.puzzle[i][j] != (count % (9)):
                    return False
                count += 1
        return True

    def swap(self, xy1, xy2):
        x1, y1 = xy1
        x2, y2 = xy2
        temp = self.puzzle[x1][y1]
        self.puzzle[x1][y1] = self.puzzle[x2][y2]
        self.puzzle[x2][y2] = temp

    def up(self):
        if (self.zero[0] != 0):
            self.swap((self.zero[0]-1, self.zero[1]), self.zero)
            self.zero = (self.zero[0]-1, self.zero[1])
            return True
        else:
            return False

    def down(self):
        if (self.zero[0] != 2):
            self.swap((self.zero[0]+1, self.zero[1]), self.zero)
            self.zero = (self.zero[0]+1, self.zero[1])
            return True
        else:
            return False

    def left(self):
        if (self.zero[1] != 0):
            self.swap((self.zero[0], self.zero[1]-1), self.zero)
            self.zero = (self.zero[0], self.zero[1]-1)
            return True
        else:
            return False

    def right(self):
        if (self.zero[1] != 2):
            self.swap((self.zero[0], self.zero[1]+1), self.zero)
            self.zero = (self.zero[0], self.zero[1]+1)
            return True
        else:
            return False

    def printPuzzle(self):
        for i in range(0, 3):
            for j in range(0, 3):
                print(self.puzzle[i][j], end=" ")
            print()

    def doMove(self, move):
        if move == "U":
            return self.up()
        if move == "D":
            return self.down()
        if move == "L":
            return self.left()
        if move == "R":
            return self.right()

    def parseMoveSequence(self, string):
        for m in string:
            self.doMove(m)

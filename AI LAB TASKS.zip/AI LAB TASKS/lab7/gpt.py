from queue import PriorityQueue
import math


class Graph:
    def __init__(self):
        self.nodes = {
            'A': (0, 0),
            'B': (1, 0),
            'C': (1, 1),
            'D': (0, 1)
        }

        self.edges = {
            'A': {'B': 8, 'C': 3, 'D': 7},
            'B': {'A': 8, 'D': 4, 'C': 1},
            'C': {'A': 3, 'B': 1, 'D': 6},
            'D': {'A': 7, 'B': 4, 'C': 6},
        }

    def neighbors(self, node):
        return self.edges[node].keys()

    def cost(self, a, b):
        return self.edges[a][b]


def euclidean_distance(a, b, nodes):
    ax, ay = nodes[a]
    bx, by = nodes[b]
    return math.sqrt((bx-ax)**2 + (by-ay)**2)


def astar_search(start, goal, graph):
    frontier = PriorityQueue()
    frontier.put((0, start))
    came_from = {}
    cost_so_far = {}
    came_from[start] = None
    cost_so_far[start] = 0

    while not frontier.empty():
        _, current = frontier.get()

        if current == goal:
            break

        for next_node in graph.neighbors(current):
            new_cost = cost_so_far[current] + graph.cost(current, next_node)
            if next_node not in cost_so_far or new_cost < cost_so_far[next_node]:
                cost_so_far[next_node] = new_cost
                priority = new_cost + \
                    euclidean_distance(next_node, goal, graph.nodes)
                frontier.put((priority, next_node))
                came_from[next_node] = current

    return came_from, cost_so_far


if __name__ == '__main__':
    graph = Graph()
    start = 'A'
    goal = 'B'
    came_from, cost_so_far = astar_search(start, goal, graph)

    # Print the shortest path found
    path = [goal]
    node = goal
    while node != start:
        node = came_from[node]
        path.append(node)
    path.reverse()
    print(path)
    print("Cost is " + str(cost_so_far[goal]))

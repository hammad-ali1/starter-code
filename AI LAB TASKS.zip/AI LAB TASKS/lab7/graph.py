from queue import PriorityQueue


class Edge:
    def __init__(self, parent, child, weight):
        self.parent = parent
        self.child = child
        self.weight = weight


class Graph:
    def __init__(self):
        self.graph = {}
        self.positions = {}

    def addNode(self, node, xy=(0, 0)):
        if node not in self.graph:
            self.graph[node] = []
            self.positions[node] = xy

    def getNeighbours(self, node) -> list:
        edges = self.getEdges(node)
        return [e.child for e in edges]

    def getEdges(self, node) -> list[Edge]:
        if node not in self.graph:
            self.graph[node] = []
        return self.graph[node]

    def addDirectedEdge(self, parent, child, weight=1):
        self.addNode(parent)
        self.addNode(child)
        edges = self.getEdges(parent)
        edges.append(Edge(parent, child, weight))

    def setPosition(self, node, xy: tuple):
        if node not in self.positions:
            raise ValueError("Node not present in graph")
        self.positions[node] = xy

    def addEdge(self, node1, node2, weight=1):
        self.addDirectedEdge(node1, node2, weight)
        self.addDirectedEdge(node2, node1, weight)

    def heuristic(self, node1, node2):
        x1, y1 = self.positions[node1]
        x2, y2 = self.positions[node2]
        return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

    def ucs(self, start, goal):
        if start not in self.graph:
            raise ValueError("Node not present in graph")
        open = PriorityQueue()
        open.put((0, start))
        closed = []
        path = {start: None}
        nodeCosts = {}
        nodeCosts[start] = 0
        while open:
            node = open.get()[1]
            if node == goal:
                return path, nodeCosts[goal]
            closed.append(node)
            edges = self.getEdges(node)
            edgesToExplore = [e for e in edges if e.child not in closed]
            for e in edgesToExplore:
                if e.child in path and nodeCosts[e.child] <= e.weight + nodeCosts[node]:
                    continue
                path[e.child] = node
                nodeCosts[e.child] = e.weight + nodeCosts[node]
                open.put((e.weight + nodeCosts[node], e.child))

    def aStar(self, start, goal):
        if start not in self.graph:
            raise ValueError("Node not present in graph")
        open = PriorityQueue()
        heuristicCost = self.heuristic(start, goal)
        open.put((heuristicCost, start))
        closed = []
        path = {start: None}
        nodeCosts = {}
        nodeCosts[start] = 0
        while open:
            node = open.get()[1]
            if node == goal:
                return path, nodeCosts[goal]
            closed.append(node)
            edges = self.getEdges(node)
            edgesToExplore = [e for e in edges if e.child not in closed]
            for e in edgesToExplore:
                if e.child in path and nodeCosts[e.child] <= e.weight + nodeCosts[node]:
                    continue
                path[e.child] = node
                nodeCosts[e.child] = e.weight + nodeCosts[node]
                open.put((e.weight + nodeCosts[node] +
                         self.heuristic(node, goal), e.child))

    def printPath(self, goal, path):
        ancestors = [goal]
        key = goal
        while path[key] != None:
            ancestors.insert(0, path[key])
            key = path[key]
        for node in ancestors:
            print(f"{node} -> ", end="")
        print("END")

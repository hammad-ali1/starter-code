from graph import Graph
if __name__ == "__main__":
    g = Graph()
    g.addEdge(1, 2)
    g.addEdge(2, 3)
    g.addEdge(1, 3)
    g.addEdge(3, 4)
    path = g.dfsTraversal(1, 4)
    g.printPath(4, path)

    path = g.bfsTraversal(1, 4)
    g.printPath(4, path)

    path = g.dijkstra(1, 4)
    g.printPath(4, path)

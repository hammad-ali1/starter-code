from graph import Graph
if __name__ == "__main__":
    g = Graph()
    g.addDirectedEdge("A", "B", 8)
    g.addDirectedEdge("A", "C", 3)
    g.addDirectedEdge("A", "D", 7)
    g.addDirectedEdge("B", "D", 4)
    g.addDirectedEdge("B", "C", 5)
    g.addDirectedEdge("C", "D", 6)

    g.setPosition("A", (0, 0))
    g.setPosition("B", (1, 0))
    g.setPosition("C", (1, 1))
    g.setPosition("D", (0, 1))

    # A star
    path, cost = g.aStar("A", "D")
    print(f"Shortest path from A to D using A* is with cost {cost}")
    g.printPath("D", path)

from queue import PriorityQueue
from math import sqrt


class Edge:
    def __init__(self, parent, child, weight):
        self.parent: str = parent
        self.child: str = child
        self.weight: int = weight


class Graph:
    def __init__(self):
        self.edges: dict[str, list[Edge]] = {}
        self.positions: dict[str, tuple[int, int]] = {}

    def set_position(self, node, xy):
        self.positions[node] = xy

    def add_node(self, node):
        if self.edges.get(node) is None:
            self.edges[node] = []

    def add_directed_edge(self, parent, child, weight):
        self.add_node(parent)
        self.add_node(child)
        self.edges[parent].append(Edge(parent, child, weight))

    def add_edge(self, node1, node2, weight):
        self.add_directed_edge(node1, node2, weight)
        self.add_directed_edge(node2, node1, weight)

    def heuristic_cost(self, node1, node2):
        x1, y1 = self.positions[node1]
        x2, y2 = self.positions[node2]
        return sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

    def astar(self, start, goal):
        frontier = PriorityQueue()
        closed = set()
        frontier.put((self.heuristic_cost(start, goal), start))
        path = {start: None}
        cumulative_costs = {node: float('inf') for node in self.edges.keys()}
        cumulative_costs[start] = 0
        while not frontier.empty():
            _, node = frontier.get()
            if node == goal:
                return path, cumulative_costs[node]
            closed.add(node)
            for edge in self.edges[node]:
                if edge.child in closed or edge.weight + cumulative_costs[node] > cumulative_costs[edge.child]:
                    continue
                new_cost = self.heuristic_cost(
                    edge.child, goal) + edge.weight + cumulative_costs[node]
                path[edge.child] = node
                cumulative_costs[edge.child] = edge.weight + \
                    cumulative_costs[node]
                frontier.put((new_cost, edge.child))


def print_path(goal, path):
    nodes = []
    current = goal
    while current:
        nodes.insert(0, current)
        current = path[current]

    for n in nodes:
        print(f"{n}->", end="")
    print("END")


g = Graph()
g.add_edge('A', 'B', 8)
g.add_edge('A', 'C', 3)
g.add_edge('A', 'D', 7)
g.add_edge('B', 'C', 1)
g.add_edge('B', 'D', 4)
g.add_edge('C', 'D', 6)

g.positions = {
    'A': (0, 0),
    'B': (1, 0),
    'C': (1, 1),
    'D': (0, 1)
}
# g.add_directed_edge("A", "B", 2)
# g.add_directed_edge("A", "C", 5)
# g.add_directed_edge("B", "D", 3)
# g.add_directed_edge("C", "D", 2)
# g.add_directed_edge("C", "E", 4)
# g.add_directed_edge("D", "F", 1)
# g.add_directed_edge("E", "F", 3)
# g.add_directed_edge("F", "G", 2)

# g.set_position("A", (0, 0))
# g.set_position("B", (0, 2))
# g.set_position("C", (2, 0))
# g.set_position("D", (2, 2))
# g.set_position("E", (4, 0))
# g.set_position("F", (4, 2))
# g.set_position("G", (6, 1))
# A star
path_dict, cost = g.astar("A", "B")
print(f"Shortest path from A to B using A* is with cost {cost}")
print_path("B", path_dict)

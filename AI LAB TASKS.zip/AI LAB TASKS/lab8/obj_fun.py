import numpy as np
import matplotlib.pyplot as plt
import random


def objective_function(x, y):
    return -x**2 - y**2 + 10


def random_neighbor(x, y, step_size):
    return x + random.uniform(-step_size, step_size), y + random.uniform(-step_size,
                                                                         step_size)


def hill_climbing(initial, step_size, max_iterations):
    current = initial
    solution_history = [current]
    for i in range(max_iterations):
        candidate = random_neighbor(*current, step_size)
        if objective_function(*candidate) > objective_function(*current):
            current = candidate
            solution_history.append(current)
        else:
            for j in range(10):
                candidate = random_neighbor(*current, step_size)
                if objective_function(*candidate) > objective_function(*current):
                    current = candidate
                    solution_history.append(current)
                break
    return current, solution_history


# Example usage
initial = (5, 5)

step_size = 1
max_iterations = 1000
solution, solution_history = hill_climbing(initial, step_size, max_iterations)
print(f"Solution: {solution} Objective value: {objective_function(*solution)}")
# Create a contour plot of the objective function
x = np.linspace(-10, 10, 100)
y = np.linspace(-10, 10, 100)
X, Y = np.meshgrid(x, y)
Z = objective_function(X, Y)
fig, ax = plt.subplots()
contour_set = ax.contour(X, Y, Z, levels=50)
ax.clabel(contour_set)
ax.set_xlabel('x')
ax.set_ylabel('y')
# Overlay the solution points on the plot
solution_history = np.array(solution_history)
ax.plot(solution_history[:, 0], solution_history[:, 1],
        '-o', color='red', linewidth=2)
plt.show()

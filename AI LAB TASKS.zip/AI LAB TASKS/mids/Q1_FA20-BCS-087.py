from queue import PriorityQueue


class Edge:
    def __init__(self, parent, child, weight):
        self.parent: str = parent
        self.child: str = child
        self.weight: int = weight


class Graph:
    def __init__(self):
        self.edges: dict[str, list[Edge]] = {}

    def add_node(self, node):
        if self.edges.get(node) is None:
            self.edges[node] = []

    def add_directed_edge(self, parent, child, weight):
        self.add_node(parent)
        self.add_node(child)
        self.edges[parent].append(Edge(parent, child, weight))

    def astar(self, start, goal, heuristic):
        open = PriorityQueue()
        closed = set()
        open.put((heuristic[start], start))
        path = {start: None}
        cumulative_costs = {node: float('inf') for node in self.edges.keys()}
        cumulative_costs[start] = 0
        while not open.empty():
            _, node = open.get()
            if node == goal:
                return path, cumulative_costs[node]
            closed.add(node)
            for edge in self.edges[node]:
                if edge.child in closed or edge.weight + cumulative_costs[node] > cumulative_costs[edge.child]:
                    continue
                new_cost = heuristic[edge.child] + \
                    edge.weight + cumulative_costs[node]
                path[edge.child] = node
                cumulative_costs[edge.child] = edge.weight + \
                    cumulative_costs[node]
                open.put((new_cost, edge.child))
        return None, None


def print_path(goal, path):
    nodes = []
    current = goal
    while current:
        nodes.insert(0, current)
        current = path[current]

    for n in nodes:
        print(f"{n}->", end="")
    print("END")


g = Graph()
g.add_directed_edge('a', 'c', 5)
g.add_directed_edge('a', 'i', 5)
g.add_directed_edge('a', 'e', 5)
g.add_directed_edge('c', 'b', 2)
g.add_directed_edge('c', 'e', 4)
g.add_directed_edge('e', 'g', 5)
g.add_directed_edge('e', 'j', 7)
g.add_directed_edge('i', 'j', 7)
g.add_directed_edge('b', 'g', 2)
g.add_directed_edge('g', 'j', 2)
g.add_directed_edge('g', 'h', 2)
g.add_directed_edge('g', 'l', 5)
g.add_directed_edge('h', 'l', 5)
g.add_directed_edge('j', 'm', 5)
g.add_directed_edge('m', 'k', 7)
g.add_directed_edge('l', 'k', 5)


heuristics = {
    'a': 15,
    'b': 9,
    'c': 13,
    'e': 9,
    'g': 5,
    'h': 2,
    'i': 8,
    'j': 4,
    'k': 0,
    'l': 5,
    'm': 7
}

# A star
path_dict, cost = g.astar("a", "k", heuristics)
print(f"Shortest path from a to k using A* is with cost {cost}")
print_path("k", path_dict)

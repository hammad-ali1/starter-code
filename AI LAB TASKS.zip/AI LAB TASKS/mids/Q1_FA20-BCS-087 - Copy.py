from queue import PriorityQueue


class Edge:
    def __init__(self, parent, child, weight):
        self.parent: str = parent
        self.child: str = child
        self.weight: int = weight


class Graph:
    def __init__(self):
        self.edges: dict[str, list[Edge]] = {}

    def add_node(self, node):
        if self.edges.get(node) is None:
            self.edges[node] = []

    def add_directed_edge(self, parent, child, weight):
        self.add_node(parent)
        self.add_node(child)
        self.edges[parent].append(Edge(parent, child, weight))

    def astar(self, start, goal, heuristic):
        open = PriorityQueue()
        closed = set()
        open.put((heuristic[start], start))
        path = {start: None}
        cumulative_costs = {node: float('inf') for node in self.edges.keys()}
        cumulative_costs[start] = 0
        while not open.empty():
            _, node = open.get()
            if node == goal:
                return path, cumulative_costs[node]
            closed.add(node)
            for edge in self.edges[node]:
                if edge.child in closed or edge.weight + cumulative_costs[node] > cumulative_costs[edge.child]:
                    continue
                new_cost = heuristic[edge.child] + \
                    edge.weight + cumulative_costs[node]
                path[edge.child] = node
                cumulative_costs[edge.child] = edge.weight + \
                    cumulative_costs[node]
                open.put((new_cost, edge.child))
        return None, None


def print_path(goal, path):
    nodes = []
    current = goal
    while current:
        nodes.insert(0, current)
        current = path[current]

    for n in nodes:
        print(f"{n}->", end="")
    print("END")


g = Graph()
g.add_directed_edge('g', 'h', 7)
g.add_directed_edge('b', 'g', 8)
g.add_directed_edge('d', 'b', 7)
g.add_directed_edge('d', 'h', 3)
g.add_directed_edge('d', 'f', 8)
g.add_directed_edge('h', 'e', 4)
g.add_directed_edge('e', 'f', 6)
g.add_directed_edge('f', 'c', 9)
g.add_directed_edge('c', 'e', 2)
g.add_directed_edge('a', 'd', 2)
g.add_directed_edge('a', 'c', 1)
g.add_directed_edge('b', 'a', 5)

heuristics = {
    'd': 12,
    'a': 1,
    'b': 5,
    'e': 10,
    'f': 8,
    'g': 24,
    'h': 11,
    'c': 0
}

# A star
path_dict, cost = g.astar("d", "c", heuristics)
print(f"Shortest path from d to c using A* is with cost {cost}")
print_path("c", path_dict)

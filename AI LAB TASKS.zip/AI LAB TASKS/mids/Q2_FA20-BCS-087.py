
class Edge:
    def __init__(self, parent, child):
        self.parent: str = parent
        self.child: str = child


class Graph:
    def __init__(self):
        self.edges: dict[str, list[Edge]] = {}

    def add_node(self, node):
        if self.edges.get(node) is None:
            self.edges[node] = []

    def add_directed_edge(self, parent, child):
        self.add_node(parent)
        self.add_node(child)
        self.edges[parent].append(Edge(parent, child))

    def add_edge(self, node1, node2):
        self.add_directed_edge(node1, node2)
        self.add_directed_edge(node2, node1)

    def bfs(self, start, goal):
        open = [start]
        closed = set()
        path = {start: None}
        while open != []:
            node = open.pop()
            if node == goal:
                return path
            closed.add(node)
            for edge in self.edges[node]:
                if edge.child in closed:
                    continue
                path[edge.child] = node
                open.append(edge.child)

    def dfs(self, start, goal):
        open = [start]
        closed = set()
        path = {start: None}
        while open != []:
            node = open.pop(0)
            if node == goal:
                return path
            closed.add(node)
            for edge in self.edges[node]:
                if edge.child in closed:
                    continue
                path[edge.child] = node
                open.append(edge.child)


def print_path(goal, path):
    nodes = []
    current = goal
    while current:
        nodes.insert(0, current)
        current = path[current]
    for n in nodes:
        print(f"{n}->", end="")
    print("END")
    return len(nodes)


g = Graph()
g.add_edge("A", "B")
g.add_edge("A", "I")
g.add_edge("A", "F")
g.add_edge("B", "E")
g.add_edge("B", "C")
g.add_edge("E", "C")
g.add_edge("E", "G")
g.add_edge("C", "D")
g.add_edge("H", "D")
g.add_edge("F", "G")
g.add_edge("G", "D")


start = 'A'
goal = 'G'
path_bfs = g.bfs(start, goal)
print(f"BFS PATH from {start} to {goal}")
count_bfs = print_path(goal, path_bfs)
print(f"Total nodes visited with BFS {count_bfs}")

print(f"DFS PATH from {start} to {goal}")
path_dfs = g.dfs(start, goal)
count_dfs = print_path(goal, path_dfs)
print(f"Total nodes visited with DFS {count_dfs}")

from graph import Graph

g = Graph()
g.add_edge(1, 2)
g.add_edge(1, 4)
g.add_edge(2, 4)
g.add_edge(2, 5)

print("Graph:")
g.print_graph()
print("DFS Traversal results on edge 1")
visited = g.dfs(1)

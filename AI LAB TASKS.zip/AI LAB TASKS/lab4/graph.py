class Graph:
    __edges = {}

    def __init__(self) -> None:
        self.__edges = {}

    def add_edge(self, v1, v2):
        if v1 not in self.__edges:
            self.__edges[v1] = []
        if v2 not in self.__edges:
            self.__edges[v2] = []
        self.__edges[v1].append(v2)
        self.__edges[v2].append(v1)

    def remove_edge(self, v1, v2):
        if v1 in self.__edges:
            self.__edges[v1].remove(v2)

    def remove_node(self, v):
        for nodes, edges in self.__edges.items():
            edges.remove(v)
        del self.__edges[v]

    def dfs(self, start, visited=None):
        if visited is None:
            visited = set()
        visited.add(start)
        for node in self.__edges[start]:
            if node not in visited:
                print(f"({start}, {node})")
                self.dfs(node, visited)

    def print_graph(self):
        print(self.__edges)
